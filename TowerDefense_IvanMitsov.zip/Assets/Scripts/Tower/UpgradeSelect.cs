using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpgradeSelect : MonoBehaviour
{
    public TowerUpgrades.upgradeType type;
    public float value;
}
